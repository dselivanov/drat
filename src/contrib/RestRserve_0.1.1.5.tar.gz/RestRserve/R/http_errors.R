# @name set_http_statuses
# @title Create standart responses/exceptions
# @description internal functions for convenient creation of standard http answers/exceptions
# @param body reponse body
# @param content_type body content type
# @param ... other parameters to \link{RestRserveResponse}


set_http_401_not_found = function(response,
                                  body = '{"error":"Resource not found"}',
                                  content_type = "application/json", ...) {
  response$body = body
  response$content_type = content_type
  response$status_code = 401L
  invisible(NULL)
}

set_http_404_not_found = function(response,
                                  body = '{"error":"Resource not found"}',
                                  content_type = "application/json", ...) {
  response$body = body
  response$content_type = content_type
  response$status_code = 404L
  invisible(NULL)
}

set_http_405_method_not_allowed = function(response,
                                           body = '{"error":"Method Not Allowed"}',
                                           content_type = "application/json", ...) {
  response$body = body
  response$content_type = content_type
  response$status_code = 405L
  invisible(NULL)
}

set_http_500_internal_server_error = function(response,
                                              body = '{"error":"Internal Server Error"}',
                                              content_type = "application/json", ...) {
  response$body = body
  response$content_type = content_type
  response$status_code = 500L
  invisible(NULL)
}

set_http_520_unknown_error  = function(response,
                                       body = '{"error":"Unknown Error"}',
                                       content_type = "application/json", ...) {
  response$body = body
  response$content_type = content_type
  response$status_code = 520L
  invisible(NULL)
}
